package TBMarketing;

import org.springframework.data.repository.PagingAndSortingRepository;

public interface TbmarketingRepository extends PagingAndSortingRepository<Tbmarketing, String>{


}