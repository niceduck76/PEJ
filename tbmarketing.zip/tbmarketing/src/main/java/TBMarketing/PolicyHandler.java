package TBMarketing;

import TBMarketing.config.kafka.KafkaProcessor;
import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cloud.stream.annotation.StreamListener;
import org.springframework.messaging.handler.annotation.Payload;
import org.springframework.stereotype.Service;

import java.util.Optional;

@Service
public class PolicyHandler{
    @StreamListener(KafkaProcessor.INPUT)
    public void onStringEventListener(@Payload String eventString){

    }

    @StreamListener(KafkaProcessor.INPUT)
    public <tbmarketing> void wheneverCancelled_ChangeInventory(@Payload Cancelled cancelled){

        if(cancelled.isMe()){

            Optional<tbmarketing> tbmarketingOptional = tbmarketingRepository.findAllByPrdIdLike(cancelled.getPrdId());
            tbmarketing tbmarketing = tbmarketingOptional.get();

            int prdQty = tbmarketing.getPrdQty() + cancelled.getPurchaseQty();

            tbmarketing.setPrdQty(prdQty);

            tbmarketingRepository.save(tbmarketing);
            System.out.println("##### listener Order : " + cancelled.toJson());

        }
        System.out.println("##### 2222listener tbmarketing_ChangeInventory : " + cancelled.toJson());
    }


    @StreamListener(KafkaProcessor.INPUT)
    public void whenevertbmarketing_ChangeInventory(@Payload Purchased purchased){

        System.out.println("#####START");

        if(purchased.isMe()){
            System.out.println("#####START_1");

            Optional<tbmarketing> productOptional = tbmarketingRepository.findAllByPrdIdLike(purchased.getPrdId());

            tbmarketing tbmarketing = tbmarketingOptional.get();

            System.out.println("#####START_2");
            System.out.println("#####tbmarketing.getPrdQty()" + tbmarketing.getPrdQty());
            System.out.println("#####purchased.getPurchaseQty()" + purchased.getPurchaseQty());

            tbmarketing.setPrdQty(tbmarketing.getPrdQty() - purchased.getPurchaseQty());
            productRepository.save(product);

        }

        System.out.println("##### 2222listener tbpurchase : " + purchased.toJson());

    }



    @StreamListener(KafkaProcessor.INPUT)
    public void wheneverPurchased_Tbpurchase(@Payload Purchased purchased){

        if(purchased.isMe()){
            System.out.println("##### listener Tbpurchase : " + purchased.toJson());
        }
    }

}
