package TBMarketing;

import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.query.Param;

import java.util.List;

public interface TbmarketingboardRepository extends CrudRepository<Tbmarketingboard, Long> {

    List<Tbmarketingboard> findByPurchaseId(String purchaseId);
}